import { useState } from "react";

export default function Home() {
  const [task, setTask] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");

  const addTask = async () => {
    if (!task) return;
    setLoading(true);
    setStatus("");
    const res = await fetch("/api/notion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task }),
    });
    if (res.ok) {
      setStatus("✅ Задача добавлена!");
      setTask("");
    } else {
      setStatus("❌ Ошибка при добавлении.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-6 rounded-2xl shadow w-96">
        <h1 className="text-xl font-bold mb-4">Добавить задачу в Notion</h1>
        <input
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Опиши задачу..."
          className="w-full border rounded-xl p-2 mb-3"
        />
        <button
          onClick={addTask}
          disabled={loading}
          className="w-full bg-black text-white rounded-xl p-2"
        >
          {loading ? "Загружаю..." : "Создать"}
        </button>
        {status && <p className="mt-3 text-sm">{status}</p>}
      </div>
    </div>
  );
}